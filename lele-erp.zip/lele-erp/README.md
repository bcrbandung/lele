# Lele ERP — Panduan Deploy ke Netlify

## File yang perlu di-upload ke Netlify:
- `index.html`
- `manifest.json`
- `sw.js`
- `netlify.toml`
- `icon-192.png`
- `icon-512.png`

## Cara Deploy (Netlify Drop):
1. Buka https://app.netlify.com/drop
2. Drag & drop **semua file** di atas ke browser
3. Tunggu deploy selesai → dapat URL seperti `https://xxxxx.netlify.app`

## Install ke HP Android:
1. Buka URL di Chrome
2. Klik menu ⋮ (tiga titik) → "Add to Home Screen"
3. Ketuk "Add" → ikon muncul di homescreen seperti app

## Install ke HP iPhone (iOS):
1. Buka URL di Safari
2. Ketuk tombol Share (kotak dengan panah ke atas)
3. Pilih "Add to Home Screen"
4. Ketuk "Add"

## Fitur:
- 📱 Works offline (data tersimpan di device)
- 🛒 Catat penjualan direct
- 📥 Catat barang masuk (beli / retur)
- 🏪 Kelola konsinyasi → rekonsiliasi → invoice
- 📦 Stock card per produk
- 👥 Data pembeli & riwayat
- 📊 Laporan harian & per produk
